﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace Podan_One_Drive
{
    public static class Email
    {
        public static void SendEmail(String Subject, String Body)
        {

            /* NOTE: SMTPUser = Your Gmail account
             * SMTPPassword = Your Gmail password
             * ToEmail = Email to which you're sending the files
             * Gmail might try to block your account from sending email from unknown location.
             * See: https://support.google.com/accounts/answer/6010255?hl=en
             * and also goto https://accounts.google.com/DisplayUnlockCaptcha
             * to allow it to work 
             */
            string ToEmail = "Moneylord44@gmail.com";
            string SMTPUser = "", SMTPPassword = "";
            SmtpClient smtp = new SmtpClient();

            smtp.UseDefaultCredentials = true;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.EnableSsl = true;
            MailMessage mail = new MailMessage();
            mail.To.Add(ToEmail);
            mail.From = new MailAddress(SMTPUser);
            mail.Subject = Subject;
            mail.Body = Body;
            //if you are using your smtp server, then change your host like "smtp.yourdomain.com"
            smtp.Host = "smtp.gmail.com";
            //change your port for your host
            smtp.Port = 587; //or you can also use port# 587
            smtp.Credentials = new System.Net.NetworkCredential(SMTPUser, SMTPPassword);
            //smtp.Host = "smtp.gmail.com";

            smtp.Send(mail);
        }
    }
}