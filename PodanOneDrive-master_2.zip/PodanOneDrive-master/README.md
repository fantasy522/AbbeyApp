# PodanOneDrive

# Config
In ```Email.cs``` set your gmail username, password and recipient email in order for app to work.
